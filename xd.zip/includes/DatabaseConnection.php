<?php
$pdo = new PDO('mysql:dbname=u645311621_merkar;host=45.13.252.1;
charset=utf8', 'u645311621_hector', 'hector1140418415');
$pdo->setAttribute(PDO::ATTR_ERRMODE,
    PDO::ERRMODE_EXCEPTION);
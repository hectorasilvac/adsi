<?php

namespace Merkar\Entity;

class User
{
    public $user_id;
    public $user_idcard;
    public $user_firstname;
    public $user_lastname;
    public $user_gender;
    public $user_phone;
    public $user_email;
    public $user_department;
    public $user_town;
    public $user_ciity;
    public $user_address;
    public $user_password;
    public $user_permissions;
}
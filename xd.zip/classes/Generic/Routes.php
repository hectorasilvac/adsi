<?php

namespace Generic;

interface Routes
{
    public function getRoutes(): array;
}